# Brainstorm de Design - Loja Rústica de Madeira

## Resposta 1: Artesanato Orgânico Contemporâneo (Probabilidade: 0.08)

**Design Movement**: Wabi-sabi moderno com influências do movimento Arts & Crafts

**Core Principles**:
- Celebrar a imperfeição e a natureza da madeira (nós, rachaduras, variações de cor)
- Minimalismo intencional com espaço negativo generoso
- Autenticidade artesanal como protagonista visual
- Navegação intuitiva que não compete com os produtos

**Color Philosophy**:
- Paleta natural: tons de madeira (caramelo, chocolate, mel), branco quente (off-white #F5F1ED), cinza natural (#8B8680)
- Acentos em verde musgo (#6B8E7F) para remeter à natureza e sustentabilidade
- Sem cores saturadas ou artificiais - tudo deve respirar naturalidade

**Layout Paradigm**:
- Grid assimétrico com produtos em tamanhos variados (alguns grandes, alguns pequenos)
- Seções com alinhamento à esquerda, criando ritmo visual desequilibrado mas harmonioso
- Muito espaço em branco entre elementos para respiração
- Imagens de produtos com fundo branco puro, sem distrações

**Signature Elements**:
- Linhas retas em madeira (divisores sutis, bordas)
- Texturas de fibra/madeira como padrão de fundo (muito sutil, 2-5% de opacidade)
- Tipografia em serif para títulos (remete a tradição artesanal)
- Pequenos detalhes de madeira (ícones, separadores) em estilo hand-drawn

**Interaction Philosophy**:
- Hover effects suaves: produtos ganham sombra mínima e escala imperceptível (1.02x)
- Transições lentas (400ms) para sensação de qualidade
- Cliques produzem feedback visual delicado (não agressivo)

**Animation**:
- Fade-in suave ao carregar produtos (300ms)
- Parallax sutil em imagens de fundo (movimento lento ao scroll)
- Hover em cards: sombra suave cresce, produto sobe 2px
- Nenhuma animação que distraia da contemplação do produto

**Typography System**:
- Display: Playfair Display (serif elegante) para títulos principais
- Body: Source Sans Pro (sans-serif limpo) para descrições
- Tamanhos: 48px (H1), 32px (H2), 18px (body), 14px (labels)

---

## Resposta 2: Rusticidade Dramática & Textural (Probabilidade: 0.07)

**Design Movement**: Industrial Rustic com toques de Dark Academia

**Core Principles**:
- Contraste dramático entre luz e sombra
- Texturas reais e palpáveis (madeira envelhecida, couro, ferro)
- Narrativa de "tesouro descoberto" - produtos são achados raros
- Atmosfera de oficina artesanal vintage

**Color Philosophy**:
- Paleta escura: preto profundo (#1A1410), marrom escuro (#3D2817), cinza carvão (#4A4A4A)
- Fundo em tons quentes de madeira envelhecida (#5C4033)
- Acentos em ouro queimado (#B8860B) para luxo artesanal
- Branco cremoso (#FAF8F3) para contraste e legibilidade

**Layout Paradigm**:
- Masonry layout com imagens grandes e pequenas intercaladas
- Seções com fundo escuro alternando com fundo claro
- Tipografia grande e ousada que domina o espaço
- Imagens de produtos com sombras dramáticas e iluminação lateral

**Signature Elements**:
- Texturas de madeira envelhecida como fundo (30-40% opacidade)
- Bordas irregulares em imagens (como se cortadas à mão)
- Ícones em estilo line-art dourado
- Padrões geométricos sutis (xadrez, linhas diagonais)

**Interaction Philosophy**:
- Hover effects com transformação: imagem ganha brilho e contraste aumenta
- Transições médias (500ms) para sensação de peso e qualidade
- Cliques produzem feedback visual com som (se possível)

**Animation**:
- Fade-in com movimento vertical (slide-up) ao carregar
- Hover em cards: imagem ganha saturação, sombra cresce dramaticamente
- Scroll trigger: elementos aparecem com efeito de revelação (como descoberta)
- Parallax mais pronunciado em imagens de fundo

**Typography System**:
- Display: Cormorant Garamond (serif clássico e elegante) para títulos
- Body: Lora (serif legível) para descrições
- Tamanhos: 56px (H1), 36px (H2), 16px (body), 13px (labels)

---

## Resposta 3: Minimalismo Nórdico Caloroso (Probabilidade: 0.06)

**Design Movement**: Scandinavian Design com toque de Japandi

**Core Principles**:
- Simplicidade funcional que não sacrifica a beleza
- Foco absoluto no produto (sem distrações)
- Paleta neutra com um único acento cromático
- Espaço negativo como ferramenta de elegância

**Color Philosophy**:
- Paleta neutra: branco puro (#FFFFFF), cinza muito claro (#F8F8F8), cinza médio (#D4D4D4)
- Fundo em bege quente (#FAF6F1) para suavidade
- Acento único em azul-acinzentado (#7A8FA3) para sofisticação
- Preto apenas para tipografia (#1F1F1F)

**Layout Paradigm**:
- Grid regular 3-coluna em desktop, muito espaçado
- Cada produto em seu próprio "respiro" visual
- Simetria deliberada e equilíbrio perfeito
- Imagens de produtos centralizadas com muito espaço ao redor

**Signature Elements**:
- Linhas horizontais muito finas (#E0E0E0) como separadores
- Ícones geométricos simples em cinza
- Tipografia sans-serif limpa e moderna
- Pequenos detalhes em azul-acinzentado (botões, highlights)

**Interaction Philosophy**:
- Hover effects minimalistas: apenas mudança de cor do texto
- Transições rápidas (250ms) para sensação de leveza
- Cliques produzem feedback visual sutil (mudança de cor)

**Animation**:
- Fade-in rápido ao carregar (200ms)
- Hover em cards: apenas mudança de cor de fundo (muito sutil)
- Nenhuma transformação de escala ou rotação
- Scroll suave sem parallax

**Typography System**:
- Display: Montserrat (sans-serif moderno) para títulos
- Body: Open Sans (sans-serif legível) para descrições
- Tamanhos: 44px (H1), 28px (H2), 16px (body), 12px (labels)

---

## Design Escolhido: Artesanato Orgânico Contemporâneo

Escolhi a **Resposta 1** porque ela melhor representa a essência de um negócio de peças artesanais rústicas. A abordagem celebra a imperfeição natural da madeira, respeitando o trabalho manual, enquanto mantém uma estética contemporânea e acessível. O minimalismo intencional não compete com os produtos, permitindo que cada peça brilhe. A paleta natural e a tipografia serif transmitem confiança artesanal, enquanto o grid assimétrico cria dinamismo sem parecer caótico.

Esta filosofia de design será aplicada em todos os arquivos CSS, componentes e páginas do projeto.
